This directory holds namespace scope `Roles` and `RolesBindings` resources for any service account on the `cicd` namespace

The main service account on the `ci` or `cicd` namespace is `pipeline` this service account is created by default on every namespace when the OpenShift Pipelines (Tekton) Operator is deploy on the cluster.

